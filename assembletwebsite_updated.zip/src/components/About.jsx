function About() {
  return (
    <section id="about">
      <h2>About Us</h2>
      <p>
        ASSEMBLET SOLUTION is a creative interior design firm based in Delhi NCR,
        specializing in residential, commercial, and turnkey interior projects that
        blend style with functionality...
      </p>
    </section>
  );
}
export default About;
