function Services() {
  return (
    <section id="services">
      <h2>Our Services</h2>
      <ul>
        <li>Residential Interior Design</li>
        <li>Commercial Interior Design</li>
        <li>Turnkey Solutions</li>
        <li>Space Planning & Layout Design</li>
        <li>Renovation Projects</li>
        <li>Modular Kitchens & Wardrobes</li>
      </ul>
    </section>
  );
}
export default Services;
