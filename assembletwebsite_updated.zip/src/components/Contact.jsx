function Contact() {
  return (
    <section id="contact">
      <h2>Contact Us</h2>
      <p>Phone: 8368263949</p>
      <p>Email: assembletsolution1@gmail.com</p>
      <p>Address: Plot No. 342, Kingwood Enclave, Sec-3, Wave City, NH-24, Ghaziabad UP</p>
    </section>
  );
}
export default Contact;
